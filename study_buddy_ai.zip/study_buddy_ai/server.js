import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const port = process.env.PORT || 3000;
const dir = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(dir, "public")));

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(openai) });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: "AI is not configured on the server yet." });
    const { messages, model = "gpt-4.1-mini" } = req.body ?? {};
    const allowed = new Set(["gpt-4.1-mini", "gpt-4.1", "gpt-4o-mini"]);
    if (!allowed.has(model)) return res.status(400).json({ error: "Unsupported model." });
    if (!Array.isArray(messages) || messages.length < 1 || messages.length > 40)
      return res.status(400).json({ error: "Send between 1 and 40 messages." });

    const input = messages.map(m => {
      if (!m || !["user", "assistant"].includes(m.role) || typeof m.content !== "string")
        throw new Error("Invalid message format.");
      return { role: m.role, content: m.content.slice(0, 12000) };
    });
    if (input.at(-1).role !== "user")
      return res.status(400).json({ error: "The last message must be from the user." });

    const response = await openai.responses.create({
      model,
      instructions: `You are Study Buddy, a thoughtful, capable AI assistant for learning and everyday life.
Solve simple and complex problems carefully. Explain difficult ideas in clear steps and adapt to the user's level.
For maths and logic, verify results. For coding, provide runnable code and explain key decisions.
For planning, turn goals into realistic actions. Be warm, practical, and honest about uncertainty.
Never claim to have completed external actions such as sending emails or booking appointments unless a connected tool actually did so.
Never ask the user to reveal passwords, API keys, or sensitive credentials.`,
      input,
      max_output_tokens: 1800
    });
    const answer = response.output_text?.trim();
    if (!answer) return res.status(502).json({ error: "The AI returned an empty answer. Please try again." });
    res.json({ answer });
  } catch (err) {
    console.error("AI request failed:", err.message);
    res.status(500).json({ error: "The AI request failed. Check server logs and API account status." });
  }
});

app.get("*", (req, res) => {
  if (req.path.startsWith("/api/")) return res.status(404).json({ error: "Not found" });
  res.sendFile(path.join(dir, "public", "index.html"));
});

app.listen(port, () => console.log(`Study Buddy listening on port ${port}`));
