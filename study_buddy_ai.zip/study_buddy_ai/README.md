# Study Buddy — AI-enabled app

## Run on a computer
1. Install Node.js 20+.
2. Extract this folder and open a terminal in it.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your own API key in `.env` as `OPENAI_API_KEY=...`.
6. Run `npm start`.
7. Open http://localhost:3000.

## Deploy
Deploy this folder to a Node.js hosting service. Set the start command to `npm start`, and add `OPENAI_API_KEY` in the host's private environment-variable settings. Never put the key in browser code, a public repository, or a chat message.

API usage is paid separately from a ChatGPT subscription. The app uses the OpenAI Responses API. Tasks and notes remain stored locally in the browser.
